# Elevate_lab_Task-2
This is my Day 2 Task in Machine Learning as a Intern in Elevate Labs during a period of 26/05/2025 - 26/06/2025
